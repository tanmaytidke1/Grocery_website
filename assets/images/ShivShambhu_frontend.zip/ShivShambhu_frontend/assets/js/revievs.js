// REVIEW JAVASCRIPT
const swiper = new Swiper(".js-reviews-slider", {
  grabCursor: true,
  spaceBetween: 30,
  pagination: {
    el: ".js-reviews-pagination",
    clickable: true,
  },
  autoplay: {
    delay: 2000, // Time in milliseconds between slide transitions (2 seconds here)
    disableOnInteraction: false, // Keep autoplay running even after user interactions
  },
  breakpoints: {
    767: {
      slidesPerView: 2,
    },
  },
});

// Pause autoplay on hover
const swiperContainer = document.querySelector(".js-reviews-slider");

// Stop autoplay on mouse enter
swiperContainer.addEventListener("mouseenter", () => {
  swiper.autoplay.stop();
});

// Resume autoplay on mouse leave
swiperContainer.addEventListener("mouseleave", () => {
  swiper.autoplay.start();
});